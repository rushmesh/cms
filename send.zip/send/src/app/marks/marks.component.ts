import { Component, OnInit } from '@angular/core';
import { NgForm,FormsModule} from '@angular/forms';
import { Login} from '../login';
import {Mark} from'../mark';
import { Router,ActivatedRoute} from '@angular/router'
import { LoginserviceService } from '../loginservice.service';
@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent implements OnInit {

  message:any;
  marks= new Mark();
  constructor(private y:LoginserviceService,  private router: Router,
    private route:ActivatedRoute) { }

  ngOnInit(): void {
  }


  id = this.route.snapshot.paramMap.get("id");
  subjectname = this.route.snapshot.paramMap.get("subjectname");
  mark=this.route.snapshot.paramMap.get("mark");
 attendenc = this.route.snapshot.paramMap.get("attendence");

  Mark()
  {
    this.marks.subjectname=this.subjectname;
    this.marks.studentid=this.id;
    if(this.marks.mark==undefined)
    this.marks.mark=this.mark;
    if(this.marks.attendence==undefined)
    this.marks.attendence=this.attendenc;
    this.y.marksUpdate(this.marks).subscribe(
      (data:Mark)=>{ 
      window.alert("Update Successfully");
      window.alert(this.attendenc);
      window.alert(this.mark);
  }  ,(error)=>{
      this.message = "connection failed some issue in contacting";
  
    window.alert("hello")
  } 

  
    
    );


  }
}
