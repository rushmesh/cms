import { Component, OnInit ,Inject} from '@angular/core';
import {MatDialog, MatDialogConfig, MatDialogModule ,MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Login} from '../login';
import { LoginserviceService } from '../loginservice.service';
import {Studentprofile} from '../studentprofile';
@Component({
  selector: 'app-addnewstudent',
  templateUrl: './addnewstudent.component.html',
  styleUrls: ['./addnewstudent.component.css']
})
export class AddnewstudentComponent implements OnInit {
 image:any;
 message:string;
 student = new Studentprofile();
image1;
 constructor(@Inject(MAT_DIALOG_DATA) public dialogRef: MatDialogRef<AddnewstudentComponent>,public dialog:MatDialog, public y:LoginserviceService,public router:Router) { }

  ngOnInit(): void {
  }

  url:string="";
  onselectedFile(e){
    if(e.target.files){
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      const file=e.target.files[0];
      this.image1=file;
      reader.onload=(event:any)=>{
        this.url=event.target.result;     }
    }
  }

  submit()
  { 
    window.alert("hello")
    this.student.pic=this.image1;
    this.y.newstudent(this.student).subscribe(
      (data:Studentprofile)=>{ 
        this.message = "Student ID->"+data.studentid+" Is Added Successfully";
        console.log("hello")
  }  ,(error)=>{
      this.message = "connection failed some issue in contacting";
  
  
  } 
    
    );
  }
}
