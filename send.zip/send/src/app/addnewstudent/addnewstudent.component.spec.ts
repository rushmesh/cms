import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddnewstudentComponent } from './addnewstudent.component';

describe('AddnewstudentComponent', () => {
  let component: AddnewstudentComponent;
  let fixture: ComponentFixture<AddnewstudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddnewstudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddnewstudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
