import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ec',
  templateUrl: './ec.component.html',
  styleUrls: ['./ec.component.css']
})
export class EcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
