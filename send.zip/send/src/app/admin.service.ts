import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEventType, HttpEvent } from '@angular/common/http';
import { map, tap, last } from "rxjs/operators";
import { BehaviorSubject } from "rxjs";
import {Observable} from 'rxjs';
import { Login} from './login'
import { Studentprofile } from './studentprofile';
import { Course } from './course';
import { FacultiesProfile } from './faculties-profile';
import { Mark } from './mark';
import {Timetable} from './timetable';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }
  
  allCourse(course:Course):Observable<Course>
  {
    let course1:any ="http://localhost:90/allCourse";
    return this.http.post<Course>(course1,Course)
  }

  addCourse(course:Course):Observable<Course>
  {

    let course1:any ="http://localhost:90/addCourse";
    return this.http.post<Course>(course1,course)
  }

  
  deleteCourse(course:Course):Observable<Course>
  {
    let course1:any ="http://localhost:90/deleteCourse";
    return this.http.post<Course>(course1,Course)
  }
  detailCourse(course:Course):Observable<Course>
  {
    let course1:any ="http://localhost:90/detailCourse";
    return this.http.post<Course>(course1,Course)
  }

  allStudent(student:Studentprofile):Observable<Studentprofile>
  {
    let student1:any ="http://localhost:7072/allstudent";
    return this.http.post<Studentprofile>(student1,student)
  }
 /*allStudent()
 {
   return this.http.get("http://localhost:7072/allstudent");
 }*/

  deletestudent(student:Studentprofile):Observable<Studentprofile>
  {
    let student1:any ="http://localhost:90/deletestudent";
    return this.http.post<Studentprofile>(student1,student)
  }

  allFaculity(staff:FacultiesProfile):Observable<FacultiesProfile>
  {
    let staff1:any ="http://localhost:7072/allFaculity";
    return this.http.post<FacultiesProfile>(staff1,staff)
  }
  
  deletestaff(staff:FacultiesProfile):Observable<FacultiesProfile>
  {
    let student1:any ="http://localhost:90/deletestaff";
    return this.http.post<FacultiesProfile>(student1,staff)
  }
  timetable(time:Timetable):Observable<Timetable>
  {
    let timetab:any="http://localhost:90/timetable";
    return this.http.post<Timetable>(timetab,time);
  }

}
