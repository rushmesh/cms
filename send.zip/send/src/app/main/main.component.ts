import { Component, OnInit } from '@angular/core';
import { StudentloginComponent } from '../studentlogin/studentlogin.component';
import { MatDialog, MatDialogConfig, MatDialogModule ,MatDialogRef} from '@angular/material/dialog';
import { Student1Component}  from '../student1/student1.component';
import { MatCommonModule } from '@angular/material/core';
import { StaffloginComponent } from '../stafflogin/stafflogin.component';
import { AdminloginComponent } from '../adminlogin/adminlogin.component';
import { from } from 'rxjs';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor(public dialog:MatDialog ) { }

  imageObject: Array<object> = [{
    image: 'assets/image/akgec1.png',
    thumbImage: 'assets/image/akgec1.png',
    alt: 'alt of image',
    title: 'college campus'
  }, {
    image: 'assets/image/akgec3.png',
    thumbImage: 'assets/image/akgec3.png',
    title: 'Events',
    alt: 'Image alt'
  }, {
    image: 'assets/image/classroom.png',
    thumbImage: 'assets/image/library.png',
    title: 'Library',
    alt: 'Image alt'
  }, {
    image: 'assets/image/classroom1.png',
    thumbImage: 'assets/image/class.png',
    title: 'classroom',
    alt: 'Image alt'
  }, {
    image: 'https://i.picsum.photos/id/613/1020/600.jpg',
    thumbImage: 'assets/image/akgechostel.png',
    title: 'Hostel',
    alt: 'Image alt'
  }, {
    image: 'https://i.picsum.photos/id/609/1020/600.jpg',
    thumbImage: 'assets/image/hostellib.png',
    title: 'Hostel Library',
    alt: 'Image alt'
  },  {
    image: 'https://i.picsum.photos/id/717/1020/600.jpg',
    thumbImage: 'assets/image/akgecaudo.png',
    title: 'Auditorium',
    alt: 'Image alt'
  }, {
    image: 'https://i.picsum.photos/id/609/1020/600.jpg',
    thumbImage: 'assets/image/lab.png',
    title: 'Lab',
    alt: 'Image alt'
  }, {
    image: 'https://i.picsum.photos/id/717/1020/600.jpg',
    thumbImage: 'assets/image/hackthon.png',
    title: 'Hackthon',
    alt: 'Image alt'
  }
  ];


  ngOnInit(): void {
  }

  onStudentLogin(){
   
 this.dialog.open(StudentloginComponent);
 this.dialog.closeAll;
   
  
}
onStaffLogin(){
   
  this.dialog.open(StaffloginComponent);
  this.dialog.closeAll;
    
   
 }
 onAdminLogin(){
   
 this.dialog.open(AdminloginComponent);
  this.dialog.closeAll;
 
   
 }


}