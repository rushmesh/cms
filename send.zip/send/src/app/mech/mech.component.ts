import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mech',
  templateUrl: './mech.component.html',
  styleUrls: ['./mech.component.css']
})
export class MechComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
