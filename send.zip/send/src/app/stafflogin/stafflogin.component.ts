import { Component, OnInit ,Inject} from '@angular/core';
import {  MatDialog, MatDialogConfig, MatDialogModule ,MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Login} from '../login';
import { LoginserviceService } from '../loginservice.service';
import { FacultiesProfile } from '../faculties-profile';
@Component({
  selector: 'app-stafflogin',
  templateUrl: './stafflogin.component.html',
  styleUrls: ['./stafflogin.component.css']
})
export class StaffloginComponent implements OnInit {
  s1:boolean=false;
  s2:boolean=false;
 login=new Login();
 staff= new FacultiesProfile();
  message:string="";
  constructor( @Inject(MAT_DIALOG_DATA) public dialogRef: MatDialogRef<StaffloginComponent>,public dialog:MatDialog, public y:LoginserviceService,public router:Router) { }

  ngOnInit(): void {
  }

  submit()
  {  
    
    if(this.staff.facultyid==undefined||this.staff.password==undefined)
    {  
      if(this.staff.facultyid==undefined)
      this.s1=true;
      else this.s2=true;
      window.alert("if")
    }
    else
    {
      window.alert(this.staff.facultyid+"   "+this.staff.password)
      
      this.y.staffLogin(this.staff).subscribe(
        (data:FacultiesProfile)=>{window.alert("subscibe work")
          if(data.facultyid==this.staff.facultyid && data.password==this.staff.password)
          {
            console.log("yes login successfull");
          
            this.router.navigate(['/staff',{id:data.facultyid,password:data.password,name:data.facultyname,doj:data.doj,department:data.department,Address:data.address,PhoneNo:data.phoneno,
              email:data.email }]);    
          }
          else
          {
            window.alert("your StudentId or Password Is Incorrect")
            this.message="your StudentId or Password Is Incorrect";
          }
        }, (error)=>{
          console.log("Connection failed not connect to server side")
          window.alert("your StudentId or Password Is Incorrect")
        }
      );
    }
  }
  
  
  }