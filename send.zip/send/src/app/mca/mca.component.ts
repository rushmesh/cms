import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mca',
  templateUrl: './mca.component.html',
  styleUrls: ['./mca.component.css']
})
export class McaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
