import { FacultiesProfile } from './faculties-profile';

describe('FacultiesProfile', () => {
  it('should create an instance', () => {
    expect(new FacultiesProfile()).toBeTruthy();
  });
});
