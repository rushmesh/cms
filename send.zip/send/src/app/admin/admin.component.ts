import { Component, OnInit ,Inject} from '@angular/core';
import { LoginserviceService } from '../loginservice.service';
import { Course} from '../course';
import { MatDialog, MatDialogConfig, MatDialogModule ,MatDialogRef} from '@angular/material/dialog';
import {AddnewstudentComponent } from '../addnewstudent/addnewstudent.component';
import { ActivatedRoute,Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import {AdminService} from '../admin.service';
import{Studentprofile} from '../studentprofile';
import {FacultiesProfile} from '../faculties-profile'
import { AddnewfaculityComponent } from '../addnewfaculity/addnewfaculity.component';
import {Timetable} from '../timetable';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit{

  my={'color':'red','background-color':'black','width':'100px','border-radius':'10px','padding':'15px,20px'}
  p1:boolean=false;
  p2:boolean=false;
  p3:boolean=true;
  p4:boolean=false;
  p5:boolean=false;
  p6:boolean=false;
  e:Course;
  std:Studentprofile;
  image:File;
  deleteid:any;
  timetable:Timetable;
  day:any;
  counter:number;//required for time table in day
 // std1:Studentprofile;
  msg:any="";
  Course:any="";
  StudentName:any ;
  Student1:any="";// y any assing krna jaruri hai beacuse ngfor in table alway work only on any isme data daalyengye
  timetab:any="";
  studentid:any;
  Staff=new FacultiesProfile();
  Staff1:any; // staff and staff1 is taken because ngfor is any type so data come in studentprofile so staff and data ko staff1 me assing kryengye
  constructor(private route: ActivatedRoute, private router: Router, public y:LoginserviceService, public y1:AdminService,public dialog:MatDialog) { 
    this.e = new Course();

  }
  ngOnInit(): void {
  }
 
    

addcourse()
{
  this.p2=false;
  this.p1=true;
 this.p3=false;
 this.p4=false;
 this.p5=false;
 this.p6=false;
  window.alert(this.e.coursename)
  this.y1.addCourse(this.e).subscribe(
    (data:Course)=>{ 
      if(data.status==1){
      this.msg = "New Course Added Successfully";
    
      }
      else{
        this.msg = " Added Unsuccessfull";
      }
      this.Course1();
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 
  
  );
}

 deletestudent(data)
{
  this.std.studentid=data;
window.alert("hello")
  this.y1.deletestudent(this.std).subscribe(
    (data:Studentprofile)=>{ 
      if(data){
      this.msg = this.e.coursename+"Course Deleted Successfully";
      }
      else{
        this.msg = this.e.coursename+" Course Not Deleted";
      }
     
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 
  
  );
}

deletestaff(x)
{
window.alert("hello")
  this.y1.deletestaff(this.Staff).subscribe(
    (data:FacultiesProfile)=>{ 
      if(data){
      this.msg = this.Staff.facultyid+" Deleted Successfully";
      }
      else{
        this.msg = this.e.coursename+" Course Not Deleted";
      }
     
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 
  
  );
}



delete()
{
  this.y1.deleteCourse(this.e).subscribe(
    (data:Course)=>{ 
      if(data.status==1){
      this.msg = this.e.coursename+"Course Deleted Successfully";
      }
      else{
        this.msg = this.e.coursename+" Course Not Deleted";
      }
     
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 
  
  );
}


detail()
{
  this.y1.detailCourse(this.e).subscribe(
    (data:Course)=>{ 
      this.Course = data;

         
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 
  
  );
}

Home()
{
  //nagivate to home
  //this.router.navigate(['/']); hum home pe nhi bhejyengyee
  this.p2=false;
  this.p1=false;
 this.p3=true;
 this.p4=false;
 this.p5=false;
 this.p6=false;
}
 Course1()
  {
    this.p6=false;
   this.p2=false;
   this.p1=true;
  this.p3=false;
  this.p4=false;
  this.p5=false;
  window.alert("btn wrk")
  this.y1.allCourse(this.e).subscribe(
    (data:Course)=>{ 
      if(data){
        this.Course=data;
      }
      else{
        window.alert("Suscribe work but something is wrong");
      }
 
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 
  
  );

  } 

  addcourse1()
  {
    this.p5=true;
    this.p2=false;
    this.p1=true;
   this.p3=false;
   this.p4=false;
   this.p6=false;
  }
Student(){
  this.p1=false;
  this.p2=true;
  this.p3=false;
  this.p4=false;
  this.p5=false;
  this.p6=false;
 this.y1.allStudent(this.std).subscribe(
    (data:Studentprofile)=>{ 
      if(data){
        this.Student1=data;
     
     
      }
      else{
        window.alert("Suscribe work but something is wrong");
      }
 
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 
  
  );

 //this.Student1= this.y1.allStudent().subscribe(data=>this.Student1=data)
}
Subjects()
{  this.p5=false;
  this.p1=false;
  this.p2=false;
  this.p3=false;
  this.p4=false;
  this.p6=false;
}
TimeTable()
{
  window.alert("timetable")
  this.p3=false;
  this.p5=false;
  this.p1=false;
  this.p2=false;
  this.p6=true;
 
}

Time()
{

   this.p3=false;
  this.p5=false;
  this.p1=false;
  this.p2=false;
  this.p6=true;
  this.p4=false;
  this.y1.timetable(this.timetable).subscribe(
    (data:Timetable)=>{ 
      if(data){
        this.timetab=data;
           window.alert(this.timetab[0].day)
           window.alert(this.timetab[0].period1)
           window.alert(this.timetab[0].period2)
           window.alert(this.timetab[0].period3)
           window.alert(this.timetab[0].period4)
           window.alert(this.timetab[0].period5)
           window.alert(this.timetab[0].period6)
           window.alert(this.timetab[0].period7)
         

      }
      else{
        window.alert("Suscribe work but something is wrong");
      }
  
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 


  
  );
}

Faculity()
{
  this.p1=false;
  this.p2=false;
  this.p3=false;
  this.p4=true;
  this.p5=false;
  this.p6=false;
  this.y1.allFaculity(this.Staff).subscribe(
    (data:FacultiesProfile)=>{ 
      if(data){
        this.Staff1=data;
        
      }
      else{
        window.alert("Suscribe work but something is wrong");
      }
 
}  ,(error)=>{
  this.msg ="ajax failed some issue in contacting";


} 
  
  );
}
addStaff()
{
  let myconfig= this.dialog.open(AddnewfaculityComponent);
  this.dialog.closeAll;

}

addStudent()
{ 
    let myconfig= this.dialog.open(AddnewstudentComponent);
     this.dialog.closeAll;
}

Search(){}
//{
 // if(this.StudentName == ""){
 //   this.ngOnInit();
 // }else
  //{
//https://www.youtube.com/watch?v=YnAn7cePiMI&t=389s
  //}
   
//}

}


