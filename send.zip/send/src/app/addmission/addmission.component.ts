import { Component, OnInit } from '@angular/core';
import {Studentprofile} from '../studentprofile';
import {} from '../login';
import { LoginserviceService } from '../loginservice.service';
@Component({
  selector: 'app-addmission',
  templateUrl: './addmission.component.html',
  styleUrls: ['./addmission.component.css']
})
export class AddmissionComponent implements OnInit {
  student = new Studentprofile();
  constructor(public y:LoginserviceService) { }
  message:string;
  ngOnInit(): void {
  }
  onFileChanged(event) {
    const file = event.target.files[0]
  }

  submit()
  {
    this.y.studentregistration(this.student).subscribe(
      (data:Studentprofile)=>{ 
        this.message = "Student ID->"+data.studentid+" Is Added Successfully";
        console.log("hello")
  }  ,(error)=>{
      this.message = "connection failed some issue in contacting";
  
  
  } 
    
    );
  }
}
