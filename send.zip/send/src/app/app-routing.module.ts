import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent} from './admin/admin.component';
import {AdminloginComponent} from  './adminlogin/adminlogin.component' ;
import {MarksComponent} from './marks/marks.component';
import {DepartmentComponent} from   './department/department.component';
import {MainComponent} from   './main/main.component';
import {StaffComponent} from   './staff/staff.component';
import {StaffloginComponent} from   './stafflogin/stafflogin.component';
import { MatDialogModule } from '@angular/material/dialog';
import {AddnewstudentComponent} from './addnewstudent/addnewstudent.component';
import {StudentloginComponent} from   './studentlogin/studentlogin.component';
import {AddmissionComponent} from './addmission/addmission.component';
import { Student1Component } from './student1/student1.component';
import { PicuploadComponent} from './picupload/picupload.component';
import{ComputerscienceComponent} from './computerscience/computerscience.component';
import{ElectricalengineeringComponent} from './electricalengineering/electricalengineering.component' ;
import{EcComponent} from './ec/ec.component' ;
import{ItComponent} from './it/it.component' ;
import{MechComponent} from './mech/mech.component' ;
import{MbaComponent} from './mba/mba.component' ;
import{McaComponent} from './mca/mca.component' ;
import{ResultComponent} from './result/result.component';

import { from } from 'rxjs';
const routes: Routes = [
 
  { path:'marks',component:MarksComponent} ,
  { path:'student',component:Student1Component},
  { path:'studentlogin',component:StudentloginComponent},
  { path:'admin',component:AdminComponent},
  { path:'adminlogin',component:AdminloginComponent},
 { path: 'addmision', component:AddmissionComponent},
  {path:'department',component:DepartmentComponent},
  { path:'staff',component:StaffComponent},
  {path:'stafflogin',component:StaffloginComponent},
  {path:'addnewstudent',component:AddnewstudentComponent},
  {path:'picupload',component:PicuploadComponent},
  {path:'cs',component:ComputerscienceComponent},
  {path:'ee',component:ElectricalengineeringComponent},
  {path:'ec',component:EcComponent},
  {path:'it',component:ItComponent},
  {path:'me',component:MechComponent},
  {path:'mba',component:MbaComponent},
  {path:'mca',component:McaComponent},
  {path:'result',component:ResultComponent},
  {path:'',component:MainComponent},
 


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  entryComponents: [StudentloginComponent,AddnewstudentComponent,PicuploadComponent]
})
export class AppRoutingModule { }
