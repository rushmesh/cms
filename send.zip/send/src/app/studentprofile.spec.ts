import { Studentprofile } from './studentprofile';

describe('Studentprofile', () => {
  it('should create an instance', () => {
    expect(new Studentprofile()).toBeTruthy();
  });
});
