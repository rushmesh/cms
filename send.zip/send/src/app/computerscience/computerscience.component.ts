import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-computerscience',
  templateUrl: './computerscience.component.html',
  styleUrls: ['./computerscience.component.css']
})
export class ComputerscienceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
