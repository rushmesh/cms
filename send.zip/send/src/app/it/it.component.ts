import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-it',
  templateUrl: './it.component.html',
  styleUrls: ['./it.component.css']
})
export class ItComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
