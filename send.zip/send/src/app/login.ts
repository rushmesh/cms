export class Login {
    userid:any;
    password:any;
}
