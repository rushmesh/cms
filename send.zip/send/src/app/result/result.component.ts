import { Component, OnInit } from '@angular/core';
import { NgForm,FormsModule} from '@angular/forms';
import { Login} from '../login';
import {Mark} from'../mark';
import { LoginserviceService } from '../loginservice.service';
import {StudentloginComponent } from '../studentlogin/studentlogin.component';
import { Router,ActivatedRoute} from '@angular/router'
import { FacultiesProfile} from '../faculties-profile';
import {Studentprofile} from '../studentprofile';
@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {
  p1:boolean=true;
  p2:boolean=false;
  Student:any="";
  student= new Studentprofile();
  marksub:any="";
  message:string="";
  totalmark:number=0;
  total:number=0;
  counter:number=0;
  percentage:number=0;
  constructor(private y:LoginserviceService,
    private router: Router,
    private route:ActivatedRoute) { }

  ngOnInit(): void {
  }


  Mark()
  { 
    
    this.p1=false;
    this.p2=true;
    this.y.markstudent(this.student).subscribe(
      (data:Mark)=>{ 
      this.marksub=data;
      for (var v in this.marksub) // for acts as a foreach  
      { 
        this.totalmark =this.totalmark +this.marksub[v].mark ;
        this.counter++;
      } 
    this.total=this.counter*100;
    this.percentage=(this.totalmark/this.total)*100;
  }  ,(error)=>{
      this.message = "connection failed some issue in contacting";
  
    window.alert("hello")
  }    
    );
  }
}
