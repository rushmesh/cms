import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectricalengineeringComponent } from './electricalengineering.component';

describe('ElectricalengineeringComponent', () => {
  let component: ElectricalengineeringComponent;
  let fixture: ComponentFixture<ElectricalengineeringComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ElectricalengineeringComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ElectricalengineeringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
