import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-electricalengineering',
  templateUrl: './electricalengineering.component.html',
  styleUrls: ['./electricalengineering.component.css']
})
export class ElectricalengineeringComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
