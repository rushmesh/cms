import { BrowserModule } from '@angular/platform-browser';
import { ANALYZE_FOR_ENTRY_COMPONENTS, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';

import { StudentloginComponent } from './studentlogin/studentlogin.component';
import { StaffloginComponent } from './stafflogin/stafflogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { MainComponent } from './main/main.component';
import { StaffComponent } from './staff/staff.component';
import { AdminComponent } from './admin/admin.component';
import{AdminService} from './admin.service';
import { DepartmentComponent } from './department/department.component';
import { NgImageSliderModule } from 'ng-image-slider';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginserviceService } from './loginservice.service';
import { HttpClientModule } from '@angular/common/http';
import { AddnewstudentComponent } from './addnewstudent/addnewstudent.component';
import { Student1Component } from './student1/student1.component';
import { AddmissionComponent } from './addmission/addmission.component';
import { PicuploadComponent } from './picupload/picupload.component';
import { MarksComponent } from './marks/marks.component';
import { ComputerscienceComponent } from './computerscience/computerscience.component';
import { ElectricalengineeringComponent } from './electricalengineering/electricalengineering.component';
import { ItComponent } from './it/it.component';
import { EcComponent } from './ec/ec.component';
import { MechComponent } from './mech/mech.component';
import { MbaComponent } from './mba/mba.component';
import { McaComponent } from './mca/mca.component';
import { ResultComponent } from './result/result.component';
import { AddnewfaculityComponent } from './addnewfaculity/addnewfaculity.component';

@NgModule({
  declarations: [
    AppComponent,
    Student1Component,
    StudentloginComponent,
    StaffloginComponent,
    AdminloginComponent,
    MainComponent,
    StaffComponent,
    AdminComponent,
  
    DepartmentComponent,
    AddnewstudentComponent,
    AddmissionComponent,
    PicuploadComponent,
    MarksComponent,
    ComputerscienceComponent,
    ElectricalengineeringComponent,
    ItComponent,
    EcComponent,
    MechComponent,
    MbaComponent,
    McaComponent,
    ResultComponent,
    AddnewfaculityComponent
   
  
  ],
  entryComponents:[StudentloginComponent],
  imports: [
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([]),
    NgImageSliderModule,
    MatDialogModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [RouterModule,LoginserviceService,AdminService,FormsModule],
  bootstrap: [AppComponent],
  
  
})
export class AppModule { }
