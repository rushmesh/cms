import { Component, OnInit ,Inject} from '@angular/core';
import {MatDialog, MatDialogConfig, MatDialogModule ,MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Login} from '../login';
import { LoginserviceService } from '../loginservice.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  s1:boolean=false;
  s2:boolean=false;
 login=new Login();
 
  message:string="";
  constructor(@Inject(MAT_DIALOG_DATA) public dialogRef: MatDialogRef<AdminloginComponent>,public dialog:MatDialog, public y:LoginserviceService,public router:Router) { }

  ngOnInit(): void {
  }

  submit()
  {  
    
    if(this.login.userid==undefined||this.login.password==undefined)
    {  
      if(this.login.userid==undefined)
      this.s1=true;
      else this.s2=true;
      
    }
    else
    {
      
      window.alert(this.login.userid);
      window.alert(this.login.password)
      
      this.y.adminLogin(this.login).subscribe(
        (data:Login)=>{
          window.alert("hello"+data.userid+"   "+data.password)
          if(data.userid==this.login.userid && data.password==this.login.password)
          {
             window.alert("hey its work")
            console.log("yes login successfull");
            this.router.navigate(['/admin']);
          
          }
          else
          {
            window.alert("your StudentId or Password Is Incorrect")
            this.message="your StudentId or Password Is Incorrect";
          }
        }, (error)=>{
          console.log("Connection failed not connect to server side")
          window.alert("your StudentId or Password Is Incorrect")
        }
      );
    }
  }
  
  
  }