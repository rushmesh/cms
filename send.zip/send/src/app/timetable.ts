export class Timetable {
    course:any;
    year:any;
    semester:any;
    period1:any;
    period2:any;
    period3:any;
    period4:any;
    period5:any;
    period6:any;
    period7:any;
   day:any;
}
