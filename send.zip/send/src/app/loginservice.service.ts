import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEventType, HttpEvent } from '@angular/common/http';
import { map, tap, last } from "rxjs/operators";
import { BehaviorSubject } from "rxjs";
import {Observable} from 'rxjs';
import { Login} from './login'
import { Studentprofile } from './studentprofile';
import { Course } from './course';
import { FacultiesProfile } from './faculties-profile';
import { Mark } from './mark';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  constructor(private http:HttpClient) { }

  studentLogin(student:Studentprofile):Observable<Studentprofile>
  {
    let studentprofile:string = "http://localhost:7072/studentlogin";
    return this.http.post<Studentprofile>(studentprofile,student)
  }
  
  staffLogin(staff:FacultiesProfile):Observable<FacultiesProfile>
  {
    let faculty:string ="http://localhost:90/stafflogin";
    return this.http.post<FacultiesProfile>(faculty,staff)
  }
  adminLogin(login:Login):Observable<Login>
  {
    let admin:any ="http://localhost:90/adminLogin";
    return this.http.post<Login>(admin,login)
  }
 



  
modifyStudent(ns:Studentprofile):Observable<Studentprofile>
{
  let x:string = "http://localhost:7072/updateStudent";
  return this.http.post<Studentprofile>(x,ns)
}

studentregistration(ns:Studentprofile):Observable<Studentprofile>
{
  let x:string = "http://localhost:7072/newstudent";
  return this.http.post<Studentprofile>(x,ns)
}
 
newstudent(ns:Studentprofile):Observable<Studentprofile>
{
  let x:string = "http://localhost:7072/newstudent";
  return this.http.post<Studentprofile>(x,ns)
}
newFaculity(ns:FacultiesProfile):Observable<FacultiesProfile>
{
  let x:string = "http://localhost:7072/newFaculity";
  return this.http.post<FacultiesProfile>(x,ns)
}
resetStudentPassword(login:Studentprofile):Observable<Studentprofile>
{
  let x:string = "http://localhost:7072/resetStudentPassword";
  return this.http.post<Studentprofile>(x,login)
}

resetFaculityPassword(login:FacultiesProfile):Observable<FacultiesProfile>
{
  let x:string = "http://localhost:7072/resetFaculityPassword";
  return this.http.post<FacultiesProfile>(x,login)
}
useremp(login:Login):Observable<Login>
{
  let x:string = "http://localhost:90/user";
  return this.http.post<Login>(x,login)
}
marksUpdate(ns:Mark):Observable<Mark>
{
  let x:string = "http://localhost:90/marksUpdate";
  return this.http.post<Mark>(x,ns)
}
markstudent(ns:Studentprofile):Observable<Mark>
{
  let x:string = "http://localhost:90/stdmark";
  return this.http.post<Mark>(x,ns)
}

attendencestudent(ns:Studentprofile):Observable<Mark>
{
  let x:string = "http://localhost:7072/attendencestudent";
  return this.http.post<Mark>(x,ns)
}

updateFaculity(ns:FacultiesProfile):Observable<FacultiesProfile>
{
  let x:string = "http://localhost:7072/updateFaculity";
  return this.http.post<FacultiesProfile>(x,ns)
}

/////for image uploading

public progressSource = new BehaviorSubject<number>(0);



upload(file: File) {
  let formData = new FormData();
  formData.append("avatar", file);

  const req = new HttpRequest(
    "POST",
    "http://localhost:90/upload",
    formData,
    {
      reportProgress: true
    }
  );

  return this.http.request(req).pipe(
    map(event => this.getEventMessage(event, file)),
    tap((envelope: any) => this.processProgress(envelope)),
    last()
  );
}

processProgress(envelope: any): void {
  if (typeof envelope === "number") {
    this.progressSource.next(envelope);
  }
}

private getEventMessage(event: HttpEvent<any>, file: File) {
  switch (event.type) {
    case HttpEventType.Sent:
      return `Uploading file "${file.name}" of size ${file.size}.`;
   
    case HttpEventType.Response:
      return `File "${file.name}" was completely uploaded!`;
    default:
      return `File "${file.name}" surprising upload event: ${event.type}.`;
  }
}

}


