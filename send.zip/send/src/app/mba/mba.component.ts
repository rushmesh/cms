import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mba',
  templateUrl: './mba.component.html',
  styleUrls: ['./mba.component.css']
})
export class MbaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
