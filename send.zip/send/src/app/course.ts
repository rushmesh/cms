export class Course {
    coursename:any;
    semester:any;
    year:any;
    status:any;
}
