import { Mark } from './mark';

describe('Mark', () => {
  it('should create an instance', () => {
    expect(new Mark()).toBeTruthy();
  });
});
