export class Studentprofile {
    studentid:any;
    password:any;
    studentname:any;
    fathername:any;
    mothername:any;
    address:any;
    phoneno:any;
    email:any;
    branch:any;
    year:any;
    dob:any;
    pic:any;

}
