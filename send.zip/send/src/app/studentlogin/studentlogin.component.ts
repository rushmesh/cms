import { Component, OnInit,Inject } from '@angular/core';
import { MatDialog, MatDialogConfig, MatDialogModule ,MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Login} from '../login';
import { LoginserviceService } from '../loginservice.service';
import { Studentprofile } from '../studentprofile';
@Component({
  selector: 'app-studentlogin',
  templateUrl: './studentlogin.component.html',
  styleUrls: ['./studentlogin.component.css']
})
export class StudentloginComponent implements OnInit {
  s1:boolean=false;
  s2:boolean=false;
 login=new Login();
 student=new Studentprofile();
  message:string="";
  constructor( @Inject(MAT_DIALOG_DATA) public dialogRef: MatDialogRef<StudentloginComponent>,public dialog:MatDialog, public logservice:LoginserviceService,public router:Router) { }

  ngOnInit(): void {
  }


  
  submit()
  {  
  
    if(this.student.studentid==undefined||this.student.password==undefined)
    {  
      if(this.student.studentid==undefined)
      this.s1=true;
      else this.s2=true;
      
    }
    else
    {
      //this.router.navigate(['/student']);
      
    //  this.dialogRef.afterClosed().subscribe(
      
      this.logservice.studentLogin(this.student).subscribe(
        (data:Studentprofile)=>{
          window.alert(this.student.password + "  "+ data.password)
          if(data.studentid==this.student.studentid&& data.password==this.student.password)
          { 
            console.log("yes login successfull");
            this.router.navigate(['/student',{StudentID:data.studentid,password:data.password,StudentName:data.studentname,FatherName:data.fathername,MotherName:data.mothername,Address:data.address,Branch:data.branch,PhoneNo:data.phoneno,pic:data.pic,
           Email:data.email,dob:data.dob,Year:data.year }]);    
          }
          else
          { window.alert("not work")
          window.alert(data.studentid+"  "+data.password+"  "+data.studentname)
            window.alert("your StudentId or Password Is Incorrect")
            this.message="your StudentId or Password Is Incorrect";
          }
        }, (error)=>{
          console.log("Connection failed not connect to server side")
          window.alert("your StudentId or Password Is Incorrect")
        }
      );
    }
  }
  
  
  }