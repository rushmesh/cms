import { Component, OnInit ,Inject} from '@angular/core';
import {MatDialog, MatDialogConfig, MatDialogModule ,MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Login} from '../login';
import { LoginserviceService } from '../loginservice.service';
import {Studentprofile} from '../studentprofile';
import {FacultiesProfile} from '../faculties-profile';
@Component({
  selector: 'app-addnewfaculity',
  templateUrl: './addnewfaculity.component.html',
  styleUrls: ['./addnewfaculity.component.css']
})
export class AddnewfaculityComponent implements OnInit {
  image:any;
  message:string;
  student = new Studentprofile();
  staff = new FacultiesProfile();
  constructor(@Inject(MAT_DIALOG_DATA) public dialogRef: MatDialogRef<AddnewfaculityComponent>,public dialog:MatDialog, public y:LoginserviceService,public router:Router) { }
 
   ngOnInit(): void {
   }
 
   onFileChanged(event) {
     const file = event.target.files[0];
      this.image=file;
   }
 
   submit()
   { 
     window.alert("hello")
     this.y.newFaculity(this.staff).subscribe(
       (data:FacultiesProfile)=>{ 
         this.message = "Faculity ID->"+data.facultyid+" Is Added Successfully";
         console.log("hello")
   }  ,(error)=>{
       this.message = "connection failed some issue in contacting";
   
   
   } 
     
     );
   }
 }
 