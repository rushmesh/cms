import { Timetable } from './timetable';

describe('Timetable', () => {
  it('should create an instance', () => {
    expect(new Timetable()).toBeTruthy();
  });
});
