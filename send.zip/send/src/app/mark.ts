export class Mark {
   subjectname:any;
   mark:any;
   studentid:any;
   attendence:any;
   
}
