export class FacultiesProfile {
    facultyid:any;
    password:any;
    facultyname:any;
    doj:any
    address:any;
    phoneno:any;
    email:any;
    department:any;

}
