import { Component, OnInit } from '@angular/core';
import { NgForm,FormsModule} from '@angular/forms';
import { Login} from '../login';
import {Mark} from'../mark';
import { LoginserviceService } from '../loginservice.service';
import {StudentloginComponent } from '../studentlogin/studentlogin.component';
import { Router,ActivatedRoute} from '@angular/router'
import { Studentprofile} from '../studentprofile';
import { fileURLToPath } from 'url';
@Component({
  selector: 'app-student1',
  templateUrl: './student1.component.html',
  styleUrls: ['./student1.component.css']
})
export class Student1Component implements OnInit {
 
  url:string;
  p1:boolean=true;
  p2:boolean=false;
  p3:boolean=false;
  p4:boolean=false;
  p5:boolean=false;
  message:string='';
  Student:any="";
  ns:Studentprofile;
  login=new Login();
  mark=new Mark();
  marksub:any;  
  Attendence:any;

  constructor( private y:LoginserviceService,
    private router: Router,
    private route:ActivatedRoute) { 
      this.ns= new Studentprofile();
       
    }

  ngOnInit(): void {
  
  }
   id = this.route.snapshot.paramMap.get("StudentID");
   pass:string = this.route.snapshot.paramMap.get("password");
   stdname:string=this.route.snapshot.paramMap.get("StudentName");
  fname:string=this.route.snapshot.paramMap.get("FatherName");
   mname:string=this.route.snapshot.paramMap.get("MotherName");
   address=this.route.snapshot.paramMap.get("Address");
   phone=this.route.snapshot.paramMap.get("PhoneNo");
   email=this.route.snapshot.paramMap.get("Email"); 
   branch=this.route.snapshot.paramMap.get("Branch");
   year=this.route.snapshot.paramMap.get("Year");
    dob=this.route.snapshot.paramMap.get("dob");
   pic=this.route.snapshot.paramMap.get("pic");

 onselectedFile(e){
   if(e.target.files){
     var reader = new FileReader();
     reader.readAsDataURL(e.target.files[0]);
     reader.onload=(event:any)=>{
       this.url=event.target.result;  
         }
   }
 }

   modify()
  { 
    this.ns.studentid=this.id;
    this.ns.pic=this.url;
    if(this.ns.studentname==undefined)
     this.ns.studentname=this.stdname;
     if(this.ns.fathername==undefined)
     this.ns.fathername=this.fname;
     if(this.ns.mothername==undefined)
     this.ns.mothername=this.mname;
     if(this.ns.address==undefined)
     this.ns.address=this.address;
     if(this.ns.phoneno==undefined)
     this.ns.phoneno=this.phone;
     if(this.ns.email==undefined)
     this.ns.email=this.email;
     if(this.ns.branch==undefined)
     this.ns.branch=this.branch;
     if(this.ns.year==undefined)
     this.ns.year=this.year;
     if(this.ns.dob==undefined)
     this.ns.dob=this.dob  
    this.y.modifyStudent(this.ns).subscribe(
      (data:Studentprofile)=>{ 
        this.message = "Student ID->"+this.id+" Is Updated Successfully";
        console.log("hello")
  }  ,(error)=>{
      this.message = "connection failed some issue in contacting";
  
  
  } 
    
    );
  }

  Mark()
  { 
    this.p1=false;
    this.p2=false;
    this.p3=false;
    this.p4=true;
    this.p5=false;
    this.ns.studentid=this.id;
    this.y.markstudent(this.ns).subscribe(
      (data:Mark)=>{ 
      this.marksub=data;
     
  }  ,(error)=>{
      this.message = "connection failed some issue in contacting";
  
  
  } 

  
    
    );

    
  }

  Profile(){
    this.p1=true;
    this.p2=false;
    this.p3=false;
    this.p4=false;
    this.p5=false;
  }
  Update(){
    this.p2=true;
    this.p1=false;
    this.p3=false;
    this.p4=false;
    this.p5=false;
  }
  Reset()
  {
    this.p3=true;
    this.p1=false;
    this.p2=false;
    this.p4=false;
    this.p5=false;
  }


  save()
  {  
    this.ns.studentid=this.id;
      this.y.resetStudentPassword(this.ns).subscribe(
        (data:Studentprofile)=>{ 
        
         this.message="Password Updated Successfully";
       
    }  ,(error)=>{
      console.log("connection failed some issue in contacting");
    
    
    } 
      
      );
    }

    Attend(){
     
      this.ns.studentid=this.id;
      this.p1=false;
      this.p2=false;
      this.p3=false;
      this.p5=true;
      this.p4=false;
      this.y.attendencestudent(this.ns).subscribe(
        (data:Mark)=>{ 
        this.Attendence=data;
    }  ,(error)=>{
        this.message = "connection failed some issue in contacting";
    
    
    } 
  
    
      
      );
    }

    Logout(){
     
      const confirmed = window.confirm('Do you want to Logout?');
     if (confirmed) {
    this.router.navigate(['/']);
    } else {
  // user did not confirm 
    }
     
    }
   
  }