import { Component, OnInit } from '@angular/core';
import { LoginserviceService} from '../loginservice.service';
@Component({
  selector: 'app-picupload',
  templateUrl: './picupload.component.html',
  styleUrls: ['./picupload.component.css']
})
export class PicuploadComponent implements OnInit {

  progress: any;
  infoMessage: any;
  isUploading: boolean = false;
  file: any;

  imageUrl: any | ArrayBuffer =
    "https://bulma.io/images/placeholders/480x480.png";
  fileName: any = "No file selected";

  constructor(private uploader: LoginserviceService) {}

  ngOnInit() {
   
  }

  onChange(file: File) {
    if (file) {
      this.fileName = file.name;
      this.file = file;

      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = event => {
        this.imageUrl = reader.result;
      };
    }
  }

  onUpload() {
    this.infoMessage = null;
    this.progress = 0;
    this.isUploading = true;

    this.uploader.upload(this.file).subscribe(message => {
      this.isUploading = false;
      this.infoMessage = message;
    });
  }
}