import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PicuploadComponent } from './picupload.component';

describe('PicuploadComponent', () => {
  let component: PicuploadComponent;
  let fixture: ComponentFixture<PicuploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PicuploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PicuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
