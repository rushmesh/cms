import { Component, OnInit } from '@angular/core';
import { NgForm,FormsModule} from '@angular/forms';
import { Login} from '../login';
import {Mark} from'../mark';
import { LoginserviceService } from '../loginservice.service';
import {StudentloginComponent } from '../studentlogin/studentlogin.component';
import { Router,ActivatedRoute} from '@angular/router'
import { FacultiesProfile} from '../faculties-profile';
import {Studentprofile} from '../studentprofile';
@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {
  s1:boolean=false;
  s2:boolean=false;
  p1:boolean=true;
  p2:boolean=false;
  p3:boolean=false;
  p4:boolean=false;
  p5:boolean=false;
  p7:boolean=false;
  message:string='';
  Student:any="";
  ns:FacultiesProfile;
  login=new Login();
  student = new Studentprofile();
  mark=new Mark();
  marksub:any;
  attendence:any;
  constructor( private y:LoginserviceService,
    private router: Router,
    private route:ActivatedRoute) { 
      this.ns= new FacultiesProfile();
      this.student=new Studentprofile();
      
    }

  ngOnInit(): void {
  }
  FacultyID:any;
  FacultyName:any;

   studentid:any;
   id = this.route.snapshot.paramMap.get("id");
   pass = this.route.snapshot.paramMap.get("password");
   name1=this.route.snapshot.paramMap.get("name");
   address=this.route.snapshot.paramMap.get("Address");
   phone=this.route.snapshot.paramMap.get("PhoneNo");
   email=this.route.snapshot.paramMap.get("email"); 
   department=this.route.snapshot.paramMap.get("department");
   year=this.route.snapshot.paramMap.get("year");
   doj=this.route.snapshot.paramMap.get("doj");
  
 
   modify()
  { 
    this.ns.facultyid=this.id;

    if(this.ns.facultyname==undefined)
    this.ns.facultyname=this.name1;

    if(this.ns.department==undefined)
    this.ns.department=this.department;

    if(this.ns.doj==undefined)
    this.ns.doj=this.doj;
    
    if(this.ns.phoneno==undefined)
    this.ns.phoneno=this.phone;
    
    if(this.ns.email==undefined)
    this.ns.email=this.email;
    
    if(this.ns.address==undefined)
    this.ns.address=this.address;
    

    

    this.y.updateFaculity(this.ns).subscribe(
      (data:FacultiesProfile)=>{ 
        this.message = "Faculty ID->"+this.ns.facultyid+" Is Updated Successfully";
        console.log("hello")
  }  ,(error)=>{
      this.message = "connection failed some issue in contacting";
  
  
  } 
    
    );
  }

  Mark()
  { 
    this.p7=true;
    this.p1=false;
    this.p2=false;
    this.p3=false;
    this.p4=false;
    this.p5=false;
     this.studentid=this.student.studentid;
    this.y.markstudent(this.student).subscribe(
      (data:Mark)=>{ 
      this.marksub=data;

      window.alert(this.marksub[0].marks);
  }  ,(error)=>{
      this.message = "connection failed some issue in contacting";
  
    window.alert("hello")
  }    
    );
  }

  Profile(){
    this.p1=true;
    this.p2=false;
    this.p3=false;
    this.p4=false;
    this.p5=false;
  }
  Update(){
    this.p2=true;
    this.p1=false;
    this.p3=false;
    this.p4=false;
    this.p5=false;
  }
  Reset()
  {
    this.p3=true;
    this.p1=false;
    this.p2=false;
    this.p4=false;
    this.p5=false;
  }
  save()
  {  
    this.ns.facultyid=this.id;
      this.y.resetFaculityPassword(this.ns).subscribe(
        (data:FacultiesProfile)=>{ 
        
         this.message="Password Updated Successfully";
       
    }  ,(error)=>{
      console.log("connection failed some issue in contacting");
    
    
    } 
      
      );
    }
    Logout(){
     
      const confirmed = window.confirm('Do you want to Logout?');
     if (confirmed) {
    this.router.navigate(['/']);
    } else {
  // user did not confirm 
    }
     
    }
  
    Student1()
    {
      this.p4=true;
      this.p1=false;
      this.p2=false;
      this.p3=false;
      this.p5=false;
    

    }

  
  }